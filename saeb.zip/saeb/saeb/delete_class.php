<?php
session_start();
require 'db.php';

if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

$class_id = $_GET['id'];
$query = "DELETE FROM classes WHERE id='$class_id'";
if (mysqli_query($conn, $query)) {
    header("Location: list_classes.php");
} else {
    echo "Error: " . $query . "<br>" . mysqli_error($conn);
}
?>
