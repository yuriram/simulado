<?php
session_start();
require 'db.php';

if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Verifique se o campo class_id está definido no formulário
    if (!empty($_POST['class_id'])) {
        $class_id = $_POST['class_id'];
    } else {
        echo "Error: Class ID is required";
        exit();
    }

    $description = $_POST['description'];

    // Verifique se um arquivo PDF foi enviado
    if ($_FILES['pdf']['error'] == UPLOAD_ERR_OK && isset($_FILES['pdf']['tmp_name'])) {
        $pdf_path = 'uploads/' . $_FILES['pdf']['name'];
        move_uploaded_file($_FILES['pdf']['tmp_name'], $pdf_path);
    } else {
        $pdf_path = '';
    }

    // Inserir atividade no banco de dados
    $query = "INSERT INTO activities (class_id, description, pdf_path) VALUES ('$class_id', '$description', '$pdf_path')";
    if (mysqli_query($conn, $query)) {
        header("Location: view_activities.php?id=$class_id");
        exit();
    } else {
        echo "Error: " . $query . "<br>" . mysqli_error($conn);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Activity</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <h2 class="mb-4">Adicionar Atividade</h2>
        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post" enctype="multipart/form-data">
            <div class="form-group">
                <label for="class_id">Turma ID:</label>
                <input type="text" class="form-control" id="class_id" name="class_id" required>
            </div>
            <div class="form-group">
                <label for="description">Descrição:</label>
                <textarea class="form-control" id="description" name="description" required></textarea>
            </div>
            <div class="form-group">
                <label for="pdf">PDF:</label>
                <input type="file" class="form-control-file" id="pdf" name="pdf">
            </div>
            <button type="submit" class="btn btn-primary">Enviar</button>
        </form>
    </div>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
