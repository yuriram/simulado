<?php
session_start();
require 'db.php';

if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

if (isset($_GET['id'])) {
    $id = $_GET['id'];
    
    // Obtenha o ID da classe antes de excluir a atividade
    $query = "SELECT class_id FROM activities WHERE id='$id'";
    $result = mysqli_query($conn, $query);
    if ($result && mysqli_num_rows($result) > 0) {
        $row = mysqli_fetch_assoc($result);
        $class_id = $row['class_id'];

        // Exclua a atividade do banco de dados
        $delete_query = "DELETE FROM activities WHERE id='$id'";
        mysqli_query($conn, $delete_query);

        // Redirecionar de volta para a página view_activities.php após a exclusão
        header("Location: view_activities.php?id=$class_id&deleted=true");
        exit();
    } else {
        echo "Error: Activity not found";
        exit();
    }
}
?>
